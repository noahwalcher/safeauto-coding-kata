package main;

public class Trip {
	
	private String name;
	
	private double milesDriven = 0;
	
	private double hoursTaken = 0;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMilesDriven() {
		return milesDriven;
	}
	public void setMilesDriven(double milesDriven) {
		this.milesDriven = milesDriven;
	}
	public double getHoursTaken() {
		return hoursTaken;
	}
	public void setHoursTaken(double hoursTaken) {
		this.hoursTaken = hoursTaken;
	}

	
	
	
}
