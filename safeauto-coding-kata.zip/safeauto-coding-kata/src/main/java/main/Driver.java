package main;

public class Driver {
	
	private String name;
	
	private int totalMiles = 0;
	
	private double hoursTaken = 0;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotalMiles() {
		return totalMiles;
	}

	public void setTotalMiles(int totalMiles) {
		this.totalMiles = totalMiles;
	}

	public double getHoursTaken() {
		return hoursTaken;
	}

	public void setHoursTaken(double hoursTaken) {
		this.hoursTaken = hoursTaken;
	}
	
	

}
